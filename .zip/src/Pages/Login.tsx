import { useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { Link, useNavigate } from "react-router-dom";

function Login() {
    const navigate = useNavigate()
    const [login, setLogin] = useState({ email: "", password: "" })
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { id, value } = e.target;
        setLogin({
            ...login, [id]: value
        })
    }
    const handleSubmit = () => {
        if (login.password === "123") {
            localStorage.setItem("token", "dummy-token")
            navigate("/dashboard")
        } else {
            alert("Invalid credential")
        }
    }
    return (
        <>
            <div className="container d-flex justify-content-center align-items-left vh-100">
                <div className="border border-primary rounded-5 p-3">
                    <form>
                        <h2>Login</h2>
                        <label htmlFor="email">Email</label>
                        <input className="form-control" value={login.email} type="email" placeholder="Enter email" onChange={handleChange} id="email" />
                        <br />
                        <label htmlFor="password">Password</label>
                        <input className="form-control" value={login.password} type="password" placeholder="Enter password" onChange={handleChange} id="password" />
                        <br />
                        <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>
                    </form>
                    <span>Don't have an account ?</span>
                    <Link to="/register">Register</Link>
                </div>
            </div>
        </>
    )
}
export default Login;