// import { useState } from "react";
import { Link } from "react-router-dom";
import Sidebar from "../Components/Sidebar";

function Dashboard() {
return(
    <div>
    <h2>Welcome admin</h2>
    <br/>
    <Sidebar/>
    <h2>Select and option below</h2>
    <Link to={"/employes"}>Employes</Link>
    <br/>
    <Link to={"/login"}>Logout</Link>
    </div>
)
}
export default Dashboard;