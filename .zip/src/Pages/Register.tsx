import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Register() {
    const [register , setRegister] = useState({name:"" , email:"" , password:"" , number:""}) 
    const navigate = useNavigate()

    const handleSubmit = () => {
        if(register.name === "" && register.name === "" && register.email === "" && register.number === "")(
            navigate("/login")
        )
    }
    return( 
        <div className="container d-flex justify-content-center align-items-left vh-100">
            <div className="border border-primary p-5 rounded-3">
                <h2>Register Page</h2>
                <form>
                <label htmlFor="name">Name</label>
                <input className="form-control" type="text" placeholder="Enter name" id="name"/>
                <br/>
                <label htmlFor="name">Email</label>
                <input className="form-control" type="text" placeholder="Enter email" id="email"/>
                <br/>
                <label htmlFor="name">Password</label>
                <input className="form-control" type="text" placeholder="Enter password" id="password"/>
                <br/>
                <label htmlFor="name">Number</label>
                <input className="form-control" type="number" placeholder="Enter number" id="number"/>
                <br/>
                <button className="btn btn-primary" onClick={handleSubmit}>Submit</button>
                </form>
            </div>
        </div>
    )
}
export default Register;